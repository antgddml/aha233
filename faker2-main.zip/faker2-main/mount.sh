#!/usr/bin/env bash

ln -s /ql/data/config /ql/config
ln -s /ql/data/db /ql/db
ln -s /ql/data/jbot /ql/jbot
ln -s /ql/data/log /ql/log
ln -s /ql/data/scripts /ql/scripts
echo "# 旧版青龙目录挂载完成。"